# Desafios de diagnóstico

Cada desafio abaixo descreve um problema real de Web: um **sintoma**, os **passos para reproduzir**, **três dicas graduais** (dica 1 é a mais leve — pare nela se já estiver no caminho), uma **evidência para registrar** e como **restaurar o estado inicial**.

Regras do laboratório:

- Ative um cenário por vez: `npm run desafio -- ativar <n>` e depois **F5** na página.
- Não abra `SOLUCOES.md` antes de tentar diagnosticar.
- Salve suas evidências em `anotacoes/evidencias/` (modelo em `anotacoes/modelo-evidencia.md`).
- Restaurou? `npm run desafio -- desativar <n>` (ou `restaurar` para desligar tudo) e F5.

> Situação atual: **todos os cinco desafios disponíveis e verificados** (veja `PROGRESSO.md`).

---

## Desafio 1 — Rota errada (404)

**Sintoma.** Ao abrir a página, a tabela não carrega: aparece "A lista não pôde ser carregada" e uma faixa de erro dizendo que a API respondeu **404**. O selo do topo continua verde ("API ok") — a API está no ar, quem está errado é o pedido.

**Passos para reproduzir**

1. `npm run desafio -- ativar 1`
2. Recarregue a página no navegador (F5).
3. Observe a tabela vazia e a mensagem de erro.
4. Abra F12 → aba **Rede**, filtre **Fetch/XHR** e clique na requisição que ficou com status 404.
5. Veja a **URL completa** e o **corpo da resposta**.

**Dicas graduais**

1. O corpo da resposta 404 tem um JSON dizendo o que aconteceu. Leia a aba **Resposta** dessa requisição.
2. Compare a rota que a página pediu com as rotas listadas em `GET /api/saude` (abra no navegador).
3. Repare no singular × plural: a página chamou `/api/pedido` e a API expõe `/api/pedidos`. O ponto onde a URL é montada é `urls()` em `public/nucleo.js`.

**Evidência para registrar.** Print da aba Rede com a requisição `GET .../api/pedido` selecionada mostrando status **404** e o corpo `{"erro": "Rota não encontrada", ...}` — anote também a URL de `/api/saude` mostrando a rota correta.

**Restaurar.** `npm run desafio -- restaurar` (ou `desativar 1`) e F5.

---

## Desafio 2 — Cadastro rejeitado (400)

**Sintoma.** O formulário está corretamente preenchido, mas ao clicar em "Registrar pedido" aparece a mensagem **"Cadastro rejeitado (400)"** listando campos que a API considera faltando/ inválidos. Nenhum pedido é criado.

**Passos para reproduzir**

1. `npm run desafio -- ativar 2`
2. Recarregue a página (F5).
3. Preencha o formulário com dados válidos e envie.
4. Abra F12 → Rede → clique no `POST /api/pedidos` com status 400.
5. Compare a aba **Carga de solicitação** (o que a página enviou) com a aba **Resposta** (o que a API reclamou).

**Dicas graduais**

1. A resposta 400 lista em `detalhes` os campos que a API não aceitou. Quais são?
2. Na aba **Carga de solicitação** do POST, confira os **nomes** dos campos enviados. Eles batem com os nomes que a API espera?
3. O payload está saindo com `nome` no lugar de `cliente` e sem `retiradaEm`. Isso acontece na função `montarPayload()` em `public/nucleo.js`.

**Evidência para registrar.** Print (ou cópia) do POST com as abas **Carga** e **Resposta**: `nome` no payload e o 400 pedindo `cliente` e `retiradaEm`.

**Restaurar.** `npm run desafio -- restaurar` (ou `desativar 2`) e F5.

---

## Desafio 3 — API inacessível (conexão recusada)

**Sintoma.** O selo do topo fica vermelho com **"API inacessível"** e a tabela mostra "Não foi possível falar com a API". Na aba Rede, as requisições aparecem em vermelho como **`(failed)` / `net::ERR_CONNECTION_REFUSED`** — o navegador não conseguiu abrir conexão com o endereço que a página usou. O terminal da API continua mostrando o servidor no ar: a API existe, a página é que está batendo na porta errada.

**Passos para reproduzir**

1. `npm run desafio -- ativar 3`
2. Recarregue a página (F5).
3. Observe o selo vermelho e a tabela sem dados.
4. Abra F12 → Rede e clique na requisição que falhou; veja a **URL completa** (porta incluída) e a mensagem de erro.
5. Confira no Console do navegador a mensagem `Failed to fetch`/`ERR_CONNECTION_REFUSED`.

**Dicas graduais**

1. Requisição com `(failed)` significa que **nada respondeu** naquele endereço. Compare a porta da URL com a porta em que a API está rodando (o terminal do `npm run dev` mostra o endereço).
2. Abra `http://localhost:3101/api/saude` direto no navegador: a API responde normalmente. Então o problema não é a API estar fora do ar — é o endereço que a página está usando.
3. A página escolhe o endereço da API em `baseApi()` (`public/nucleo.js`). Com o cenário ativo, ela usa `apiPortaErrada` (4099) em vez de `apiPort` (3101). Você também consegue ver isso abrindo `http://localhost:5180/config.js`.

**Evidência para registrar.** Print da aba Rede com a requisição `(failed) net::ERR_CONNECTION_REFUSED` e a URL contendo a porta **4099** — ao lado, print (ou anotação) do `GET /api/saude` respondendo 200 na porta **3101**.

**Restaurar.** `npm run desafio -- restaurar` (ou `desativar 3`) e F5.

> Extensão opcional: com todos os cenários desligados, pare a API (Ctrl+C no terminal em que ela roda) e recarregue a página. O sintoma de conexão recusada é o mesmo — essa é a forma "de verdade" de viver o problema, sem porta artificial.

---

## Desafio 4 — CORS bloqueando a leitura da resposta

**Sintoma.** A lista carrega normalmente, mas ao cadastrar aparece **"Falha de rede ao cadastrar"** — e, mesmo assim, na aba Rede o `POST /api/pedidos` aparece com status **201**. No Console do navegador há um erro começando com *"Access to fetch … has been blocked by CORS policy"*. Se recarregar a página (F5), o pedido **está lá**: ele foi criado, o JavaScript é que não conseguiu ler a resposta.

**Passos para reproduzir**

1. `npm run desafio -- ativar 4`
2. Recarregue a página (F5).
3. Cadastre um pedido com dados válidos.
4. Abra F12 → **Rede** → clique no `POST /api/pedidos` (status 201) → aba **Cabeçalhos**.
5. Abra a aba **Console** e leia o erro de CORS.
6. Recarregue a página: o pedido aparece na lista.

**Dicas graduais**

1. Status 201 na Rede + mensagem de falha na página significa que a **resposta chegou**, mas o navegador não entregou o conteúdo ao JavaScript. Esse é o comportamento clássico de CORS.
2. No Console, procure "blocked by CORS policy". Qual cabeçalho o navegador diz que está faltando na resposta?
3. Compare os cabeçalhos de resposta do `GET /api/pedidos` (que funciona) com os do `POST`: falta `Access-Control-Allow-Origin` no POST. Na API, veja `cabecalhosCors()` e a regra `bloqueioDeLeitura` em `servidor/api.mjs`.

**Evidência para registrar.** Print do Console com o erro de CORS + print do POST com status 201 e sem `Access-Control-Allow-Origin` na aba Cabeçalhos + confirmação de que o pedido aparece após F5.

**Restaurar.** `npm run desafio -- restaurar` (ou `desativar 4`) e F5.

> Por que o pedido é criado mesmo assim? O navegador **envia** o POST (o preflight foi autorizado). O bloqueio acontece na hora de **entregar a resposta** ao JavaScript da página. O servidor já processou e gravou o pedido. Isso confunde muita gente — e é justamente o detalhe que o painel Rede revela.

---

## Desafio 5 — Lista desatualizada (201, mas o item não aparece)

**Sintoma.** O cadastro é aceito: aparece a mensagem verde **"Pedido #X registrado…"** e na aba Rede o `POST /api/pedidos` mostra **201 Created** com o pedido no corpo da resposta. Mesmo assim, a tabela não mostra o pedido novo. Ele só aparece depois de **recarregar a página** (F5) ou clicar em "Recarregar lista". Não há nenhum erro no Console.

**Passos para reproduzir**

1. `npm run desafio -- ativar 5`
2. Recarregue a página (F5).
3. Cadastre um pedido com dados válidos.
4. Observe a mensagem de sucesso e a tabela ainda sem o pedido.
5. Abra F12 → Rede → `POST /api/pedidos` → confirme **201** e o pedido no corpo da resposta.
6. Recarregue a página (F5): o pedido aparece.

**Dicas graduais**

1. Se a API respondeu 201 com o pedido, o dado **existe**. O problema está no que a página faz **depois** de receber a resposta — e a aba Rede já mostrou que a requisição deu certo.
2. Procure no seu fluxo de cadastro o passo que atualiza a tabela. Ele é executado sempre? Quem chama a função que recarrega a lista após o sucesso do POST?
3. Em `public/app.js`, o bloco de sucesso do POST chama `deveRecarregarLista(DESAFIOS)`. Essa função está em `public/nucleo.js` e, com este cenário, retorna `false` — a recarga é pulada de propósito.

**Evidência para registrar.** Print da mensagem de sucesso + tabela sem o pedido + a requisição POST com status **201** e o corpo contendo o pedido criado — e o mesmo pedido aparecendo depois do F5.

**Restaurar.** `npm run desafio -- restaurar` (ou `desativar 5`) e F5.
