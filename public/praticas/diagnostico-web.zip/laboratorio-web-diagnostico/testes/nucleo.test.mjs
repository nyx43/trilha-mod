// Testes das funções puras do frontend (public/nucleo.js).
// Comprovam o fluxo de referência e o efeito de cada cenário ativo nas URLs/payloads.
import test from 'node:test';
import assert from 'node:assert/strict';
import { DESAFIOS_PADRAO, urls, montarPayload, deveRecarregarLista } from '../public/nucleo.js';

const CONFIG = { apiHost: 'localhost', apiPort: 3101, apiPortaErrada: 4099, webPort: 5180 };

const DADOS_FORMULARIO = {
  cliente: 'Ana Souza',
  telefone: '(11) 98888-1111',
  produto: 'Bolo de cenoura',
  quantidade: '2',
  retiradaEm: '2026-11-20T10:00',
};

test('fluxo de referência: URLs apontam para as rotas corretas da API', () => {
  const enderecos = urls(CONFIG, DESAFIOS_PADRAO);
  assert.equal(enderecos.base, 'http://localhost:3101');
  assert.equal(enderecos.saude, 'http://localhost:3101/api/saude');
  assert.equal(enderecos.lista, 'http://localhost:3101/api/pedidos');
  assert.equal(enderecos.cadastro, 'http://localhost:3101/api/pedidos');
});

test('desafio 1 (rota errada): a lista passa a pedir /api/pedido', () => {
  const enderecos = urls(CONFIG, { ...DESAFIOS_PADRAO, rotaErrada: true });
  assert.equal(enderecos.lista, 'http://localhost:3101/api/pedido');
  // o restante continua correto, para o diagnóstico comparar as requisições
  assert.equal(enderecos.saude, 'http://localhost:3101/api/saude');
  assert.equal(enderecos.cadastro, 'http://localhost:3101/api/pedidos');
});

test('fluxo de referência: payload de cadastro segue o contrato da API', () => {
  const payload = montarPayload(DADOS_FORMULARIO, DESAFIOS_PADRAO);
  assert.equal(payload.cliente, 'Ana Souza');
  assert.equal(payload.produto, 'Bolo de cenoura');
  assert.equal(payload.quantidade, 2);
  assert.equal(Number.isNaN(Date.parse(payload.retiradaEm)), false);
});

test('fluxo de referência: data vazia ou inválida vira string vazia (a API responde 400)', () => {
  const semData = montarPayload({ ...DADOS_FORMULARIO, retiradaEm: '' }, DESAFIOS_PADRAO);
  assert.equal(semData.retiradaEm, '');
  const dataInvalida = montarPayload({ ...DADOS_FORMULARIO, retiradaEm: 'não é data' }, DESAFIOS_PADRAO);
  assert.equal(dataInvalida.retiradaEm, '');
});

test('desafio 2 (cadastro rejeitado): payload sai com nome no lugar de cliente e sem retiradaEm', () => {
  const payload = montarPayload(DADOS_FORMULARIO, { ...DESAFIOS_PADRAO, cadastroRejeitado: true });
  assert.equal('cliente' in payload, false);
  assert.equal('retiradaEm' in payload, false);
  assert.equal(payload.nome, 'Ana Souza');
  assert.equal(payload.quantidade, 2);
});

test('desafio 3 (API inacessível): todas as URLs usam a porta errada', () => {
  const enderecos = urls(CONFIG, { ...DESAFIOS_PADRAO, apiInacessivel: true });
  assert.equal(enderecos.base, 'http://localhost:4099');
  assert.equal(enderecos.saude, 'http://localhost:4099/api/saude');
  assert.equal(enderecos.lista, 'http://localhost:4099/api/pedidos');
  assert.equal(enderecos.cadastro, 'http://localhost:4099/api/pedidos');
});

test('desafio 5 (lista desatualizada): a recarga da lista é pulada após o cadastro', () => {
  assert.equal(deveRecarregarLista(DESAFIOS_PADRAO), true);
  assert.equal(deveRecarregarLista({ ...DESAFIOS_PADRAO, listaDesatualizada: true }), false);
});
