// Testes dos servidores reais (API e servidor web) em portas efêmeras.
// Cobrem o fluxo de referência, as respostas 404/400/405 e o config.js servido ao navegador.
import test, { after, before } from 'node:test';
import assert from 'node:assert/strict';
import { criarServidorApi } from '../servidor/api.mjs';
import { criarServidorWeb } from '../servidor/web.mjs';

const CONFIG_TESTE = { apiHost: '127.0.0.1', apiPort: 3101, webHost: '127.0.0.1', webPort: 5180, apiPortaErrada: 4099 };
const RETIRADA = new Date(Date.now() + 24 * 3600 * 1000).toISOString();

let apiRef;
let baseApi;
let apiCors;
let baseCors;
let webSrv;
let baseWeb;

function ouvir(servidor) {
  return new Promise((resolver) => {
    servidor.listen(0, '127.0.0.1', () => resolver(`http://127.0.0.1:${servidor.address().port}`));
  });
}

function fechar(servidor) {
  return new Promise((resolver) => servidor.close(() => resolver()));
}

before(async () => {
  // API sem cenários ativos, com dados em memória (não toca em dados/pedidos.json)
  apiRef = criarServidorApi({
    config: CONFIG_TESTE,
    lerEstado: () => ({ ativos: [] }),
    caminhoDados: null,
  });
  baseApi = await ouvir(apiRef);

  // API com o cenário 4 ativo, para conferir o bloqueio de leitura por CORS
  apiCors = criarServidorApi({
    config: CONFIG_TESTE,
    lerEstado: () => ({ ativos: [4] }),
    caminhoDados: null,
  });
  baseCors = await ouvir(apiCors);

  // Servidor web com o cenário 1 ativo, para conferir o config.js gerado
  webSrv = criarServidorWeb({
    config: CONFIG_TESTE,
    lerEstado: () => ({ ativos: [1] }),
  });
  baseWeb = await ouvir(webSrv);
});

after(async () => {
  await fechar(apiRef);
  await fechar(apiCors);
  await fechar(webSrv);
});

test('GET /api/saude responde 200 com ok:true e lista de rotas', async () => {
  const resposta = await fetch(`${baseApi}/api/saude`);
  const corpo = await resposta.json();
  assert.equal(resposta.status, 200);
  assert.equal(corpo.ok, true);
  assert.ok(corpo.rotas.includes('GET /api/pedidos'));
});

test('GET /api/pedidos responde 200 com os pedidos de exemplo', async () => {
  const resposta = await fetch(`${baseApi}/api/pedidos`);
  const corpo = await resposta.json();
  assert.equal(resposta.status, 200);
  assert.ok(Array.isArray(corpo.pedidos));
  assert.ok(corpo.pedidos.length >= 2);
  assert.equal(typeof corpo.pedidos[0].cliente, 'string');
});

test('fluxo de referência: POST válido cria pedido (201 + Location) e ele aparece no GET seguinte', async () => {
  const resposta = await fetch(`${baseApi}/api/pedidos`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ cliente: 'Cliente Teste', produto: 'Bolo simples', quantidade: 2, retiradaEm: RETIRADA }),
  });
  const criado = await resposta.json();
  assert.equal(resposta.status, 201);
  assert.equal(resposta.headers.get('location'), `/api/pedidos/${criado.id}`);
  assert.equal(criado.cliente, 'Cliente Teste');
  assert.equal(criado.status, 'aguardando');

  const lista = await (await fetch(`${baseApi}/api/pedidos`)).json();
  assert.ok(lista.pedidos.some((pedido) => pedido.id === criado.id));
});

test('POST com dados inválidos responde 400 e detalha os campos', async () => {
  const resposta = await fetch(`${baseApi}/api/pedidos`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ nome: 'Sem cliente', telefone: '', produto: 'Bolo', quantidade: 2 }),
  });
  const corpo = await resposta.json();
  assert.equal(resposta.status, 400);
  assert.equal(corpo.erro, 'Dados inválidos');
  const campos = corpo.detalhes.map((detalhe) => detalhe.campo);
  assert.ok(campos.includes('cliente'));
  assert.ok(campos.includes('retiradaEm'));
});

test('POST com JSON malformado responde 400 com erro de leitura', async () => {
  const resposta = await fetch(`${baseApi}/api/pedidos`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: '{ isso não é json',
  });
  const corpo = await resposta.json();
  assert.equal(resposta.status, 400);
  assert.equal(corpo.erro, 'JSON inválido');
});

test('GET /api/pedido (singular — rota do desafio 1) responde 404 com "Rota não encontrada"', async () => {
  const resposta = await fetch(`${baseApi}/api/pedido`);
  const corpo = await resposta.json();
  assert.equal(resposta.status, 404);
  assert.equal(corpo.erro, 'Rota não encontrada');
  assert.equal(corpo.caminho, '/api/pedido');
  assert.ok(corpo.dica.includes('GET /api/pedidos'));
});

test('GET /api/pedidos/999 responde 404 de pedido não encontrado', async () => {
  const resposta = await fetch(`${baseApi}/api/pedidos/999`);
  const corpo = await resposta.json();
  assert.equal(resposta.status, 404);
  assert.equal(corpo.erro, 'Pedido não encontrado');
});

test('método não permitido em rota conhecida responde 405', async () => {
  const resposta = await fetch(`${baseApi}/api/pedidos`, { method: 'DELETE' });
  const corpo = await resposta.json();
  assert.equal(resposta.status, 405);
  assert.deepEqual(corpo.permitidos, ['GET', 'POST']);
});

test('CORS de referência: origem do painel é liberada em GET e POST', async () => {
  const origem = 'http://localhost:5180';
  const get = await fetch(`${baseApi}/api/pedidos`, { headers: { Origin: origem } });
  assert.equal(get.headers.get('access-control-allow-origin'), origem);

  const post = await fetch(`${baseApi}/api/pedidos`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Origin: origem },
    body: JSON.stringify({ cliente: 'CORS Ok', produto: 'Rosca', quantidade: 1, retiradaEm: RETIRADA }),
  });
  assert.equal(post.status, 201);
  assert.equal(post.headers.get('access-control-allow-origin'), origem);
});

test('CORS de referência: origem desconhecida não recebe Allow-Origin', async () => {
  const resposta = await fetch(`${baseApi}/api/pedidos`, { headers: { Origin: 'http://outra-origem.example' } });
  assert.equal(resposta.status, 200);
  assert.equal(resposta.headers.get('access-control-allow-origin'), null);
});

test('desafio 4 (CORS): preflight e GET continuam liberados', async () => {
  const origem = 'http://localhost:5180';
  const preflight = await fetch(`${baseCors}/api/pedidos`, {
    method: 'OPTIONS',
    headers: {
      Origin: origem,
      'Access-Control-Request-Method': 'POST',
      'Access-Control-Request-Headers': 'content-type',
    },
  });
  assert.equal(preflight.status, 204);
  assert.equal(preflight.headers.get('access-control-allow-origin'), origem);
  assert.ok(preflight.headers.get('access-control-allow-headers').includes('Content-Type'));

  const get = await fetch(`${baseCors}/api/pedidos`, { headers: { Origin: origem } });
  assert.equal(get.status, 200);
  assert.equal(get.headers.get('access-control-allow-origin'), origem);
});

test('desafio 4 (CORS): POST responde 201, cria o pedido, mas sai sem Allow-Origin', async () => {
  const origem = 'http://localhost:5180';
  const resposta = await fetch(`${baseCors}/api/pedidos`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Origin: origem },
    body: JSON.stringify({ cliente: 'Criado Mas Bloqueado', produto: 'Bolo', quantidade: 1, retiradaEm: RETIRADA }),
  });
  assert.equal(resposta.status, 201);
  assert.equal(resposta.headers.get('access-control-allow-origin'), null);

  // o pedido existe no servidor mesmo com o bloqueio de leitura no navegador
  const lista = await (await fetch(`${baseCors}/api/pedidos`)).json();
  assert.ok(lista.pedidos.some((pedido) => pedido.cliente === 'Criado Mas Bloqueado'));
});

test('servidor web: GET / entrega a interface da loja', async () => {
  const resposta = await fetch(baseWeb);
  const html = await resposta.text();
  assert.equal(resposta.status, 200);
  assert.ok(html.includes('Pedidos de retirada'));
  assert.ok(html.includes('Registrar novo pedido'));
});

test('servidor web: /config.js reflete portas e cenários ativos', async () => {
  const resposta = await fetch(`${baseWeb}/config.js`);
  const texto = await resposta.text();
  assert.equal(resposta.status, 200);
  assert.ok(texto.includes('window.LAB'));
  assert.ok(texto.includes('"apiPort": 3101'));
  assert.ok(texto.includes('"rotaErrada": true'));
  assert.ok(texto.includes('"cadastroRejeitado": false'));
  assert.ok(texto.includes('"desafiosAtivos": ['));
});

test('servidor web: arquivo inexistente responde 404', async () => {
  const resposta = await fetch(`${baseWeb}/nao-existe.css`);
  assert.equal(resposta.status, 404);
});
