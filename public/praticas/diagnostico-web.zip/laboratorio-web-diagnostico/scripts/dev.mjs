// Sobe a API e o servidor web juntos (npm run dev) e derruba os dois com Ctrl+C.
import { spawn } from 'node:child_process';
import { join } from 'node:path';
import { RAIZ, lerConfig, lerEstadoDesafios } from '../config.mjs';

const config = lerConfig();
const estado = lerEstadoDesafios();

console.log('[lab] iniciando API e servidor web…');
console.log(`[lab] interface: http://${config.webHost}:${config.webPort}`);
console.log(`[lab] API:       http://${config.apiHost}:${config.apiPort}  (saúde: /api/saude)`);
console.log(`[lab] desafios ativos: ${estado.ativos.length ? estado.ativos.map((n) => `#${n}`).join(', ') : 'nenhum'}`);
console.log('[lab] para encerrar: Ctrl+C\n');

const filhos = [
  spawn(process.execPath, [join(RAIZ, 'servidor', 'api.mjs')], { stdio: 'inherit' }),
  spawn(process.execPath, [join(RAIZ, 'servidor', 'web.mjs')], { stdio: 'inherit' }),
];

let encerrando = false;

function encerrar(codigo = 0) {
  if (encerrando) return;
  encerrando = true;
  for (const filho of filhos) {
    if (!filho.killed) filho.kill('SIGTERM');
  }
  setTimeout(() => process.exit(codigo), 300);
}

for (const filho of filhos) {
  filho.on('exit', (codigo) => {
    if (!encerrando) {
      console.error(`\n[lab] um dos servidores encerrou (código ${codigo}). Encerrando o outro.`);
      encerrar(codigo ?? 1);
    }
  });
}

process.on('SIGINT', () => encerrar(0));
process.on('SIGTERM', () => encerrar(0));
