// Verificação de fumaça: sobe API + servidor web de verdade (processos filhos, em
// portas de teste) e confere o fluxo de referência com requisições reais.
// Uso: npm run fumaca
import { spawn } from 'node:child_process';
import { existsSync, rmSync } from 'node:fs';
import { join } from 'node:path';
import { RAIZ, lerEstadoDesafios } from '../config.mjs';

const PORTA_API = 3901;
const PORTA_WEB = 3902;
const CAMINHO_DADOS_TESTE = join(RAIZ, 'dados', 'pedidos.fumaca.json');
const ORIGEM_WEB = `http://localhost:${PORTA_WEB}`;

const resultado = { ok: 0, falhas: 0 };

function conferir(condicao, descricao, detalhe = '') {
  if (condicao) {
    resultado.ok += 1;
    console.log(`  ✅ ${descricao}`);
  } else {
    resultado.falhas += 1;
    console.log(`  ❌ ${descricao}${detalhe ? ` — ${detalhe}` : ''}`);
  }
}

async function esperarServidor(url, tentativas = 40) {
  for (let i = 0; i < tentativas; i += 1) {
    try {
      await fetch(url);
      return true;
    } catch {
      await new Promise((resolver) => setTimeout(resolver, 150));
    }
  }
  return false;
}

rmSync(CAMINHO_DADOS_TESTE, { force: true });

const ambiente = {
  ...process.env,
  LAB_API_PORT: String(PORTA_API),
  LAB_WEB_PORT: String(PORTA_WEB),
  LAB_DADOS: CAMINHO_DADOS_TESTE,
};

const api = spawn(process.execPath, [join(RAIZ, 'servidor', 'api.mjs')], { env: ambiente, stdio: 'inherit' });
const web = spawn(process.execPath, [join(RAIZ, 'servidor', 'web.mjs')], { env: ambiente, stdio: 'inherit' });

let encerrando = false;

function encerrar(codigo) {
  if (encerrando) return;
  encerrando = true;
  for (const filho of [api, web]) {
    if (!filho.killed) filho.kill('SIGTERM');
  }
  rmSync(CAMINHO_DADOS_TESTE, { force: true });
  setTimeout(() => process.exit(codigo), 250);
}

try {
  const apiBase = `http://localhost:${PORTA_API}`;
  const webBase = `http://localhost:${PORTA_WEB}`;

  const apiPronta = await esperarServidor(`${apiBase}/api/saude`);
  const webPronto = await esperarServidor(webBase);
  if (!apiPronta || !webPronto) {
    console.error('[fumaca] os servidores não subiram a tempo.');
    encerrar(1);
  }

  console.log('\n[fumaca] verificando fluxo de referência…\n');

  // 1. Saúde
  const saude = await fetch(`${apiBase}/api/saude`);
  const corpoSaude = await saude.json();
  conferir(saude.status === 200 && corpoSaude.ok === true, 'GET /api/saude responde 200');

  // 2. Lista inicial
  const listaInicial = await fetch(`${apiBase}/api/pedidos`);
  const corpoLista = await listaInicial.json();
  conferir(listaInicial.status === 200 && Array.isArray(corpoLista.pedidos), 'GET /api/pedidos responde 200 com lista');
  conferir(corpoLista.pedidos.length >= 2, 'lista começa com pedidos de exemplo');

  // 3. Cadastro válido
  const retirada = new Date(Date.now() + 24 * 3600 * 1000).toISOString();
  const cadastro = await fetch(`${apiBase}/api/pedidos`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ cliente: 'Fumaça Teste', produto: 'Pão de queijo', quantidade: 3, retiradaEm: retirada }),
  });
  const corpoCadastro = await cadastro.json();
  conferir(cadastro.status === 201 && corpoCadastro.id > 0, 'POST /api/pedidos válido responde 201');
  conferir(cadastro.headers.get('location') === `/api/pedidos/${corpoCadastro.id}`, 'resposta 201 traz o cabeçalho Location');

  // 4. O item aparece na lista
  const listaDepois = await fetch(`${apiBase}/api/pedidos`);
  const corpoDepois = await listaDepois.json();
  conferir(corpoDepois.pedidos.some((pedido) => pedido.id === corpoCadastro.id), 'pedido novo aparece no GET seguinte');

  // 5. Cadastro inválido
  const invalido = await fetch(`${apiBase}/api/pedidos`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ quantidade: 0 }),
  });
  const corpoInvalido = await invalido.json();
  conferir(invalido.status === 400, 'POST /api/pedidos inválido responde 400');
  conferir(
    Array.isArray(corpoInvalido.detalhes) && corpoInvalido.detalhes.some((item) => item.campo === 'cliente'),
    'resposta 400 explica o campo "cliente" em detalhes',
  );

  // 6. Rota do desafio 1 (singular) e rota inexistente
  const rotaErrada = await fetch(`${apiBase}/api/pedido`);
  const corpoRotaErrada = await rotaErrada.json();
  conferir(rotaErrada.status === 404 && corpoRotaErrada.erro === 'Rota não encontrada', 'GET /api/pedido responde 404 (rota do desafio 1)');

  const inexistente = await fetch(`${apiBase}/api/nao-existe`);
  conferir(inexistente.status === 404, 'GET /api/nao-existe responde 404');

  // 7. Servidor web
  const home = await fetch(webBase);
  const html = await home.text();
  conferir(home.status === 200 && html.includes('Pedidos de retirada'), 'GET / serve a interface da loja');

  const configJs = await fetch(`${webBase}/config.js`);
  const textoConfig = await configJs.text();
  conferir(configJs.status === 200 && textoConfig.includes('window.LAB'), 'GET /config.js entrega a configuração do laboratório');
  conferir(textoConfig.includes(`"apiPort": ${PORTA_API}`), 'config.js aponta para a porta de teste da API');

  // 8. CORS com a origem do painel
  const estado = lerEstadoDesafios();
  const desafioCorsAtivo = estado.ativos.includes(4);

  const getCors = await fetch(`${apiBase}/api/pedidos`, { headers: { Origin: ORIGEM_WEB } });
  conferir(
    getCors.headers.get('access-control-allow-origin') === ORIGEM_WEB,
    'GET com origem do painel recebe Access-Control-Allow-Origin',
  );

  const postCors = await fetch(`${apiBase}/api/pedidos`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Origin: ORIGEM_WEB },
    body: JSON.stringify({ cliente: 'CORS Teste', produto: 'Rosca', quantidade: 1, retiradaEm: retirada }),
  });
  const allowPost = postCors.headers.get('access-control-allow-origin');
  if (desafioCorsAtivo) {
    conferir(postCors.status === 201 && allowPost === null, 'desafio 4 ativo: POST responde 201 SEM Allow-Origin (bloqueio de leitura)');
  } else {
    conferir(postCors.status === 201 && allowPost === ORIGEM_WEB, 'POST com origem do painel recebe Allow-Origin');
  }

  // 9. Estado do config.js reflete os desafios ativos
  if (estado.ativos.length > 0) {
    conferir(
      textoConfig.includes(`"desafiosAtivos": [${estado.ativos.join(', ')}]`) ||
        estado.ativos.every((numero) => textoConfig.includes(String(numero))),
      `config.js reflete os desafios ativos (#${estado.ativos.join(', #')})`,
    );
  } else {
    conferir(textoConfig.includes('"desafiosAtivos": []'), 'config.js mostra nenhum desafio ativo');
  }

  console.log(`\n[fumaca] resultado: ${resultado.ok} verificações ok, ${resultado.falhas} falha(s).`);
  encerrar(resultado.falhas === 0 ? 0 : 1);
} catch (erro) {
  console.error('[fumaca] erro inesperado:', erro);
  encerrar(1);
}
