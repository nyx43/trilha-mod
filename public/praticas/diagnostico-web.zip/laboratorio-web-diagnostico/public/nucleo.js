// Núcleo do frontend: funções puras (sem DOM) que decidem URLs e payloads.
// É usado pelo navegador (via app.js) e pelos testes em Node (testes/nucleo.test.mjs),
// o que permite verificar os cenários sem abrir o navegador.
//
// Alguns cenários ativos mudam o comportamento abaixo; a explicação completa fica
// em DESAFIOS.md e a solução em SOLUCOES.md.

export const DESAFIOS_PADRAO = {
  rotaErrada: false,
  cadastroRejeitado: false,
  apiInacessivel: false,
  listaDesatualizada: false,
};

export function baseApi(config, desafios = DESAFIOS_PADRAO) {
  if (desafios.apiInacessivel) {
    // O cenário ativo aponta para uma porta onde nada escuta (ver DESAFIOS.md, desafio 3).
    return `http://${config.apiHost}:${config.apiPortaErrada}`;
  }
  return `http://${config.apiHost}:${config.apiPort}`;
}

export function urls(config, desafios = DESAFIOS_PADRAO) {
  const base = baseApi(config, desafios);
  return {
    base,
    saude: `${base}/api/saude`,
    lista: `${base}${desafios.rotaErrada ? '/api/pedido' : '/api/pedidos'}`,
    cadastro: `${base}/api/pedidos`,
  };
}

function paraIso(valor) {
  if (!valor) return '';
  const data = new Date(valor);
  return Number.isNaN(data.getTime()) ? '' : data.toISOString();
}

export function montarPayload(dados, desafios = DESAFIOS_PADRAO) {
  const payload = {
    cliente: String(dados.cliente ?? '').trim(),
    telefone: String(dados.telefone ?? '').trim(),
    produto: String(dados.produto ?? '').trim(),
    quantidade: Number(dados.quantidade),
    retiradaEm: paraIso(dados.retiradaEm),
  };
  if (desafios.cadastroRejeitado) {
    // O cenário ativo altera o contrato do corpo enviado (ver DESAFIOS.md, desafio 2).
    const comContratoAlterado = { ...payload, nome: payload.cliente };
    delete comContratoAlterado.cliente;
    delete comContratoAlterado.retiradaEm;
    return comContratoAlterado;
  }
  return payload;
}

export function deveRecarregarLista(desafios = DESAFIOS_PADRAO) {
  // No cenário 5, o cadastro é confirmado mas a tabela não é atualizada.
  return !desafios.listaDesatualizada;
}
