// Interface da loja: consulta e cadastro de pedidos de retirada.
// Toda decisão de URL/payload vem de nucleo.js; aqui só há DOM e fetch.
import { DESAFIOS_PADRAO, urls, montarPayload, deveRecarregarLista } from './nucleo.js';

const CONFIG_PADRAO = { apiHost: 'localhost', apiPort: 3101, apiPortaErrada: 4099, webPort: 5180 };
const LAB = window.LAB || {};
const CONFIG = { ...CONFIG_PADRAO, ...(LAB.config || {}) };
const DESAFIOS = { ...DESAFIOS_PADRAO, ...(LAB.desafios || {}) };

const elementos = {
  form: document.getElementById('form-cadastro'),
  cliente: document.getElementById('campo-cliente'),
  telefone: document.getElementById('campo-telefone'),
  produto: document.getElementById('campo-produto'),
  quantidade: document.getElementById('campo-quantidade'),
  retirada: document.getElementById('campo-retirada'),
  mensagem: document.getElementById('mensagem'),
  corpoTabela: document.getElementById('corpo-tabela'),
  contador: document.getElementById('contador-pedidos'),
  botaoRecarregar: document.getElementById('botao-recarregar'),
  textoConexao: document.getElementById('texto-conexao'),
  bolinhaConexao: document.getElementById('bolinha-conexao'),
  registro: document.getElementById('registro'),
  faixaCenario: document.getElementById('faixa-cenario'),
};

// ---------------------------------------------------------------------------
// Utilidades de tela
// ---------------------------------------------------------------------------
function registrar(mensagem) {
  const item = document.createElement('li');
  item.textContent = `${new Date().toLocaleTimeString('pt-BR')} — ${mensagem}`;
  elementos.registro.prepend(item);
}

function mostrarMensagem(tipo, texto) {
  elementos.mensagem.hidden = false;
  elementos.mensagem.className = `mensagem ${tipo}`;
  elementos.mensagem.textContent = texto;
}

function limparMensagem() {
  elementos.mensagem.hidden = true;
  elementos.mensagem.textContent = '';
}

function escapeHtml(valor) {
  return String(valor ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;');
}

function formatarDataHora(iso) {
  const data = new Date(iso);
  if (Number.isNaN(data.getTime())) return '—';
  return data.toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' });
}

function marcarConexao(ok, texto) {
  elementos.bolinhaConexao.className = `bolinha ${ok ? 'ok' : 'falha'}`;
  elementos.textoConexao.textContent = texto;
}

function preencherRetiradaPadrao() {
  const amanha = new Date();
  amanha.setDate(amanha.getDate() + 1);
  amanha.setHours(10, 0, 0, 0);
  const local = new Date(amanha.getTime() - amanha.getTimezoneOffset() * 60000).toISOString().slice(0, 16);
  elementos.retirada.value = local;
}

// ---------------------------------------------------------------------------
// Chamadas à API
// ---------------------------------------------------------------------------
async function verificarSaude() {
  const endereco = urls(CONFIG, DESAFIOS).saude;
  try {
    const resposta = await fetch(endereco);
    if (!resposta.ok) {
      marcarConexao(false, `API respondeu ${resposta.status}`);
      registrar(`GET ${endereco} → ${resposta.status}`);
      return;
    }
    marcarConexao(true, 'API ok');
    registrar(`GET ${endereco} → 200`);
  } catch (erro) {
    marcarConexao(false, 'API inacessível');
    registrar(`GET ${endereco} → falha de rede (${erro.message})`);
  }
}

function renderizarPedidos(pedidos) {
  elementos.contador.textContent = `${pedidos.length} pedido(s)`;
  if (!pedidos.length) {
    elementos.corpoTabela.innerHTML = '<tr><td colspan="7" class="vazio">Nenhum pedido registrado.</td></tr>';
    return;
  }
  elementos.corpoTabela.innerHTML = pedidos
    .map(
      (pedido) => `
      <tr>
        <td>${escapeHtml(pedido.id)}</td>
        <td>${escapeHtml(pedido.cliente)}</td>
        <td>${escapeHtml(pedido.produto)}</td>
        <td>${escapeHtml(pedido.quantidade)}</td>
        <td>${formatarDataHora(pedido.retiradaEm)}</td>
        <td><span class="etiqueta">${escapeHtml(pedido.status)}</span></td>
        <td>${formatarDataHora(pedido.criadoEm)}</td>
      </tr>`,
    )
    .join('');
}

async function carregarPedidos() {
  const endereco = urls(CONFIG, DESAFIOS).lista;
  elementos.corpoTabela.innerHTML = '<tr><td colspan="7" class="vazio">Carregando pedidos…</td></tr>';

  let resposta;
  try {
    resposta = await fetch(endereco);
  } catch (erro) {
    elementos.corpoTabela.innerHTML = '<tr><td colspan="7" class="vazio">Não foi possível falar com a API.</td></tr>';
    elementos.contador.textContent = '—';
    mostrarMensagem('erro', `Falha de rede ao consultar a lista. Abra F12 → Rede e veja a requisição que falhou (${endereco}).`);
    registrar(`GET ${endereco} → falha de rede (${erro.message})`);
    return;
  }

  registrar(`GET ${endereco} → ${resposta.status}`);

  if (!resposta.ok) {
    let detalhe = '';
    try {
      const corpo = await resposta.json();
      if (corpo && corpo.erro) detalhe = ` — ${corpo.erro}`;
    } catch {
      // resposta sem JSON legível; segue com a mensagem genérica
    }
    elementos.corpoTabela.innerHTML = '<tr><td colspan="7" class="vazio">A lista não pôde ser carregada.</td></tr>';
    elementos.contador.textContent = '—';
    mostrarMensagem('erro', `A API respondeu ${resposta.status}${detalhe} para GET ${endereco}.`);
    return;
  }

  const corpo = await resposta.json();
  renderizarPedidos(corpo.pedidos || []);
}

async function enviarCadastro(evento) {
  evento.preventDefault();
  limparMensagem();

  const endereco = urls(CONFIG, DESAFIOS).cadastro;
  const payload = montarPayload(
    {
      cliente: elementos.cliente.value,
      telefone: elementos.telefone.value,
      produto: elementos.produto.value,
      quantidade: elementos.quantidade.value,
      retiradaEm: elementos.retirada.value,
    },
    DESAFIOS,
  );

  let resposta;
  try {
    resposta = await fetch(endereco, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
  } catch (erro) {
    mostrarMensagem(
      'erro',
      `Falha de rede ao cadastrar (${endereco}). A requisição pode não ter chegado, ou a resposta não pôde ser lida. Abra F12 → Console e Rede para investigar.`,
    );
    registrar(`POST ${endereco} → falha de rede (${erro.message})`);
    return;
  }

  registrar(`POST ${endereco} → ${resposta.status}`);

  if (resposta.status === 201) {
    const pedido = await resposta.json();
    mostrarMensagem('sucesso', `Pedido #${pedido.id} registrado para ${pedido.cliente}.`);
    elementos.form.reset();
    preencherRetiradaPadrao();
    if (deveRecarregarLista(DESAFIOS)) {
      await carregarPedidos();
    }
    return;
  }

  if (resposta.status === 400) {
    let detalhes = [];
    try {
      const corpo = await resposta.json();
      if (Array.isArray(corpo.detalhes)) detalhes = corpo.detalhes;
    } catch {
      // segue com a mensagem genérica
    }
    const texto = detalhes.length
      ? detalhes.map((detalhe) => `${detalhe.campo}: ${detalhe.mensagem}`).join(' | ')
      : 'A API rejeitou os dados enviados.';
    mostrarMensagem('erro', `Cadastro rejeitado (400). ${texto} Confira em F12 → Rede → POST → aba Carga de solicitação.`);
    return;
  }

  mostrarMensagem('erro', `Resposta inesperada da API: ${resposta.status}. Veja a aba Rede para o detalhe.`);
}

// ---------------------------------------------------------------------------
// Inicialização
// ---------------------------------------------------------------------------
preencherRetiradaPadrao();

if (LAB.desafiosAtivos && LAB.desafiosAtivos.length > 0) {
  elementos.faixaCenario.hidden = false;
  elementos.faixaCenario.textContent = `Cenário de diagnóstico ativo: #${LAB.desafiosAtivos.join(', #')}. O fluxo de referência continua documentado no README.`;
}

elementos.form.addEventListener('submit', enviarCadastro);
elementos.botaoRecarregar.addEventListener('click', carregarPedidos);

verificarSaude();
carregarPedidos();
