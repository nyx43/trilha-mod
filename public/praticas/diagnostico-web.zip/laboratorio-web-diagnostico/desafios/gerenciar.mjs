// Gerencia os cenários de diagnóstico do laboratório.
//
// Uso:
//   npm run desafio -- listar
//   npm run desafio -- ativar 1
//   npm run desafio -- desativar 1
//   npm run desafio -- restaurar          (desliga todos — estado inicial)
//   npm run desafio -- resetar-dados      (apaga os pedidos e volta aos exemplos)
import { rmSync } from 'node:fs';
import { join } from 'node:path';
import { DESAFIOS, RAIZ, lerEstadoDesafios, salvarEstadoDesafios } from '../config.mjs';

const CAMINHO_DADOS = join(RAIZ, 'dados', 'pedidos.json');
const [, , comando, argumento] = process.argv;

function ajuda() {
  console.log(`Uso: npm run desafio -- <comando>

Comandos:
  listar             mostra o estado atual dos cenários
  ativar <n>         liga o cenário n (depois recarregue a página com F5)
  desativar <n>      desliga o cenário n (depois recarregue a página com F5)
  restaurar          desliga todos os cenários (estado inicial)
  resetar-dados      apaga os pedidos de teste; os exemplos voltam na próxima consulta

Enunciados e dicas: DESAFIOS.md | Soluções: SOLUCOES.md`);
}

function avisoRecarregar() {
  console.log('→ Recarregue a página do laboratório no navegador (F5) para o cenário valer.');
}

function exigirDesafio(valor) {
  const numero = Number(valor);
  const desafio = DESAFIOS.find((item) => item.numero === numero);
  if (!desafio) {
    console.error(`[desafio] informe um número entre 1 e ${DESAFIOS.length}. Recebi: ${valor ?? '(nada)'}`);
    process.exitCode = 1;
    return null;
  }
  return desafio;
}

function listar() {
  const ativos = new Set(lerEstadoDesafios().ativos);
  console.log('Cenários do laboratório:');
  for (const desafio of DESAFIOS) {
    console.log(`  ${ativos.has(desafio.numero) ? '[x]' : '[ ]'} #${desafio.numero} ${desafio.titulo}`);
  }
  if (ativos.size > 0) avisoRecarregar();
}

const estado = lerEstadoDesafios();

if (!comando || comando === 'ajuda' || comando === 'help') {
  ajuda();
  if (!comando) listar();
} else if (comando === 'listar') {
  listar();
} else if (comando === 'ativar') {
  const desafio = exigirDesafio(argumento);
  if (desafio) {
    const ativos = [...new Set([...estado.ativos, desafio.numero])].sort((a, b) => a - b);
    salvarEstadoDesafios(ativos);
    console.log(`[desafio] cenário #${desafio.numero} ativado: ${desafio.titulo}`);
    if (ativos.length > 1) {
      console.log('[desafio] atenção: há mais de um cenário ativo; o ideal é investigar um por vez.');
    }
    avisoRecarregar();
    console.log('→ Enunciado e dicas em DESAFIOS.md | solução em SOLUCOES.md');
  }
} else if (comando === 'desativar') {
  const desafio = exigirDesafio(argumento);
  if (desafio) {
    const ativos = estado.ativos.filter((numero) => numero !== desafio.numero);
    salvarEstadoDesafios(ativos);
    console.log(`[desafio] cenário #${desafio.numero} desativado: ${desafio.titulo}`);
    avisoRecarregar();
  }
} else if (comando === 'restaurar') {
  salvarEstadoDesafios([]);
  console.log('[desafio] todos os cenários desativados (estado inicial).');
  avisoRecarregar();
} else if (comando === 'resetar-dados') {
  rmSync(CAMINHO_DADOS, { force: true });
  console.log('[desafio] pedidos apagados; os pedidos de exemplo voltam na próxima consulta à API.');
} else {
  console.error(`[desafio] comando desconhecido: ${comando}`);
  ajuda();
  process.exitCode = 1;
}
