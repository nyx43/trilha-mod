# Modelo de evidência

Copie este arquivo para `anotacoes/evidencias/` (um por desafio, ex.: `desafio-01-evidencia.md`) e preencha durante a investigação. Prints e arquivos HAR também podem ser salvos nessa pasta.

---

- **Data:** 
- **Desafio:** #__ — nome do cenário
- **Sintoma observado:** (o que a página mostrou)

## Requisição investigada

- **Método e URL:** (ex.: `GET http://localhost:3101/api/pedido`)
- **Status e tempo:** (ex.: `404 · 2 ms`)
- **Iniciador:** (quem disparou — `app.js`, formulário, etc.)
- **Cabeçalhos relevantes:** (ex.: `Origin`, `Access-Control-Allow-Origin`)
- **Corpo enviado:** (aba Carga de solicitação, se POST)
- **Corpo recebido:** (aba Resposta/Pré-visualização)

## Console

- Mensagens de erro relacionadas (ex.: CORS, tipo de erro do fetch):

## Conclusão

- **Causa identificada:** 
- **Como confirmei:** 
- **O que mudaria no código:** 

## Restauração

- Comando usado para voltar ao estado inicial (`npm run desafio -- ...`) e resultado após F5:
