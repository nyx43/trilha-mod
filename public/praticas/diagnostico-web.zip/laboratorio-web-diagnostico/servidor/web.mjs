// Servidor web do laboratório: entrega o frontend (public/) e gera /config.js
// com as portas e o estado atual dos desafios lido de desafios/estado.json.
import { createServer } from 'node:http';
import { readFileSync, realpathSync } from 'node:fs';
import { extname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { RAIZ, lerConfig, lerEstadoDesafios, mapaDesafios } from '../config.mjs';

const PASTA_PUBLICA_PADRAO = join(RAIZ, 'public');

const TIPOS = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
  '.txt': 'text/plain; charset=utf-8',
};

export function scriptConfig(config, ativos) {
  const dados = {
    config: {
      apiHost: config.apiHost,
      apiPort: config.apiPort,
      apiPortaErrada: config.apiPortaErrada,
      webPort: config.webPort,
    },
    desafios: mapaDesafios(ativos),
    desafiosAtivos: ativos,
    geradoEm: new Date().toISOString(),
  };
  return `// Gerado pelo servidor web a cada carregamento (sem cache).\nwindow.LAB = ${JSON.stringify(dados, null, 2)};\n`;
}

export function criarServidorWeb(opcoes = {}) {
  const {
    config = lerConfig(),
    lerEstado = lerEstadoDesafios,
    pastaPublica = PASTA_PUBLICA_PADRAO,
  } = opcoes;

  return createServer((req, res) => {
    const url = new URL(req.url || '/', 'http://localhost');
    const caminho = url.pathname;
    const hora = () => new Date().toLocaleTimeString('pt-BR');

    if (req.method !== 'GET') {
      res.writeHead(405, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('O servidor web do laboratório só responde GET.\n');
      console.log(`[web] ${hora()} ${req.method} ${caminho} -> 405`);
      return;
    }

    if (caminho === '/config.js') {
      const ativos = lerEstado().ativos;
      const corpo = scriptConfig(config, ativos);
      res.writeHead(200, { 'Content-Type': 'text/javascript; charset=utf-8', 'Cache-Control': 'no-store' });
      res.end(corpo);
      console.log(`[web] ${hora()} GET /config.js -> 200 (desafios ativos: ${ativos.length ? ativos.join(', ') : 'nenhum'})`);
      return;
    }

    const relativo = caminho === '/' ? 'index.html' : caminho.slice(1);
    if (relativo.includes('..')) {
      res.writeHead(403, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('Caminho não permitido.\n');
      console.log(`[web] ${hora()} GET ${caminho} -> 403`);
      return;
    }

    try {
      const arquivo = join(pastaPublica, relativo);
      const conteudo = readFileSync(arquivo);
      res.writeHead(200, {
        'Content-Type': TIPOS[extname(arquivo).toLowerCase()] || 'application/octet-stream',
        'Cache-Control': 'no-store',
      });
      res.end(conteudo);
      console.log(`[web] ${hora()} GET ${caminho} -> 200`);
    } catch {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end(`Arquivo não encontrado no servidor web: ${caminho}\n`);
      console.log(`[web] ${hora()} GET ${caminho} -> 404`);
    }
  });
}

export function iniciar() {
  const config = lerConfig();
  const servidor = criarServidorWeb({ config });
  servidor.on('error', (erro) => {
    if (erro.code === 'EADDRINUSE') {
      console.error(`[web] a porta ${config.webPort} já está em uso.`);
      console.error('[web] ajuste "webPort" em lab.config.json ou rode: LAB_WEB_PORT=5190 npm run web');
    } else {
      console.error('[web] falha ao iniciar:', erro);
    }
    process.exit(1);
  });
  servidor.listen(config.webPort, config.webHost, () => {
    console.log(`[web] interface no ar em http://${config.webHost}:${config.webPort}`);
  });
  return servidor;
}

const ehPrincipal = process.argv[1] && realpathSync(process.argv[1]) === fileURLToPath(import.meta.url);
if (ehPrincipal) iniciar();
