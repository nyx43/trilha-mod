// API local do laboratório (sem dependências externas).
// Rotas:
//   GET  /api/saude          -> 200, lista rotas disponíveis
//   GET  /api/pedidos        -> 200, lista de pedidos de retirada
//   POST /api/pedidos        -> 201 criado | 400 dados inválidos
//   GET  /api/pedidos/:id    -> 200 | 404
//   demais rotas             -> 404
//   método errado em rota conhecida -> 405
//
// CORS: por padrão, respostas liberam a origem do servidor web (lab.config.json).
// O cenário "cors" desliga essa liberação na resposta do POST (veja DESAFIOS.md).
import { createServer } from 'node:http';
import { mkdirSync, readFileSync, realpathSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { RAIZ, lerConfig, lerEstadoDesafios, mapaDesafios } from '../config.mjs';

const CAMINHO_DADOS_PADRAO = join(RAIZ, 'dados', 'pedidos.json');
const LIMITE_CORPO = 1_000_000;

// ---------------------------------------------------------------------------
// Repositório de pedidos (arquivo JSON local ou memória, usado nos testes)
// ---------------------------------------------------------------------------
function pedidosDeExemplo() {
  const agora = new Date();
  const amanha = new Date(agora);
  amanha.setDate(amanha.getDate() + 1);
  const retirada1 = new Date(amanha);
  retirada1.setHours(10, 0, 0, 0);
  const retirada2 = new Date(amanha);
  retirada2.setHours(14, 0, 0, 0);
  return [
    {
      id: 1,
      cliente: 'Ana Souza',
      telefone: '(11) 98888-1111',
      produto: 'Bolo de cenoura (encomenda)',
      quantidade: 1,
      retiradaEm: retirada1.toISOString(),
      status: 'aguardando',
      criadoEm: agora.toISOString(),
    },
    {
      id: 2,
      cliente: 'Bruno Lima',
      telefone: '(11) 97777-2222',
      produto: 'Torta de frango',
      quantidade: 2,
      retiradaEm: retirada2.toISOString(),
      status: 'aguardando',
      criadoEm: agora.toISOString(),
    },
  ];
}

export function criarRepositorio(caminhoArquivo) {
  let emMemoria = null;

  function ler() {
    if (!caminhoArquivo) {
      if (!emMemoria) emMemoria = pedidosDeExemplo();
      return emMemoria;
    }
    try {
      return JSON.parse(readFileSync(caminhoArquivo, 'utf8'));
    } catch {
      const semente = pedidosDeExemplo();
      salvar(semente);
      return semente;
    }
  }

  function salvar(lista) {
    if (!caminhoArquivo) {
      emMemoria = lista;
      return;
    }
    mkdirSync(dirname(caminhoArquivo), { recursive: true });
    writeFileSync(caminhoArquivo, `${JSON.stringify(lista, null, 2)}\n`);
  }

  return {
    listar: () => ler(),
    criar(dados) {
      const lista = ler();
      const id = lista.reduce((maior, pedido) => Math.max(maior, pedido.id), 0) + 1;
      const pedido = { id, ...dados, status: 'aguardando', criadoEm: new Date().toISOString() };
      lista.push(pedido);
      salvar(lista);
      return pedido;
    },
  };
}

// ---------------------------------------------------------------------------
// Validação e leitura de corpo
// ---------------------------------------------------------------------------
export function validarPedido(corpo) {
  if (!corpo || typeof corpo !== 'object' || Array.isArray(corpo)) {
    return [{ campo: 'corpo', mensagem: 'envie um objeto JSON com os dados do pedido' }];
  }
  const detalhes = [];
  const texto = (valor) => (typeof valor === 'string' ? valor.trim() : '');

  const cliente = texto(corpo.cliente);
  if (cliente.length < 2 || cliente.length > 80) {
    detalhes.push({ campo: 'cliente', mensagem: 'informe o nome do cliente (2 a 80 caracteres)' });
  }
  const produto = texto(corpo.produto);
  if (produto.length < 2 || produto.length > 80) {
    detalhes.push({ campo: 'produto', mensagem: 'informe o produto (2 a 80 caracteres)' });
  }
  if (!Number.isInteger(corpo.quantidade) || corpo.quantidade < 1 || corpo.quantidade > 99) {
    detalhes.push({ campo: 'quantidade', mensagem: 'a quantidade deve ser um número inteiro entre 1 e 99' });
  }
  if (typeof corpo.retiradaEm !== 'string' || Number.isNaN(Date.parse(corpo.retiradaEm))) {
    detalhes.push({ campo: 'retiradaEm', mensagem: 'informe a data de retirada em formato ISO (ex.: 2026-11-16T10:00:00.000Z)' });
  }
  const telefone = texto(corpo.telefone);
  if (telefone.length > 0 && !/^[0-9()+\-\s.]{8,20}$/.test(telefone)) {
    detalhes.push({ campo: 'telefone', mensagem: 'telefone deve ter de 8 a 20 caracteres (números, espaços, parênteses, + ou -)' });
  }
  return detalhes;
}

function lerCorpoJson(req) {
  return new Promise((resolver) => {
    let dados = '';
    let excedeu = false;
    req.on('data', (pedaco) => {
      if (excedeu) return;
      dados += pedaco;
      if (dados.length > LIMITE_CORPO) excedeu = true;
    });
    req.on('end', () => {
      if (excedeu) return resolver({ erro: 'corpo maior que 1 MB' });
      if (!dados.trim()) return resolver({ erro: 'corpo vazio; envie JSON' });
      try {
        resolver({ valor: JSON.parse(dados) });
      } catch (erro) {
        resolver({ erro: `JSON malformado: ${erro.message}` });
      }
    });
    req.on('error', () => resolver({ erro: 'falha ao ler o corpo da requisição' }));
  });
}

// ---------------------------------------------------------------------------
// CORS
// ---------------------------------------------------------------------------
export function origensPermitidas(config) {
  const hosts = new Set(['localhost', '127.0.0.1', config.webHost]);
  const lista = [];
  for (const host of hosts) lista.push(`http://${host}:${config.webPort}`);
  return lista;
}

export function cabecalhosCors(req, config, permitir) {
  const origem = req.headers.origin;
  if (!origem) return {};
  if (!origensPermitidas(config).includes(origem)) return { Vary: 'Origin' };
  if (!permitir) return { Vary: 'Origin' };
  return {
    'Access-Control-Allow-Origin': origem,
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Max-Age': '600',
    Vary: 'Origin',
  };
}

// ---------------------------------------------------------------------------
// Despacho
// ---------------------------------------------------------------------------
function rotasPermitidas(caminho) {
  if (caminho === '/api/saude') return ['GET'];
  if (caminho === '/api/pedidos') return ['GET', 'POST'];
  if (/^\/api\/pedidos\/\d+$/.test(caminho)) return ['GET'];
  return null;
}

function responder(res, resultado, cors) {
  const cabecalhos = { ...cors, ...(resultado.headers || {}), 'Cache-Control': 'no-store' };
  if (resultado.status === 204) {
    res.writeHead(204, cabecalhos);
    res.end();
    return;
  }
  const corpo = JSON.stringify(resultado.corpo ?? {}, null, 2);
  cabecalhos['Content-Type'] = 'application/json; charset=utf-8';
  cabecalhos['Content-Length'] = Buffer.byteLength(corpo);
  res.writeHead(resultado.status, cabecalhos);
  res.end(corpo);
}

function agora() {
  return new Date().toLocaleTimeString('pt-BR');
}

function criarManipulador({ repositorio, config, lerEstado }) {
  return async function manipular(req, res) {
    const metodo = (req.method || 'GET').toUpperCase();
    const url = new URL(req.url || '/', `http://${req.headers.host || 'localhost'}`);
    const caminho = url.pathname;
    const desafios = mapaDesafios(lerEstado().ativos);
    let resultado;

    try {
      if (metodo === 'OPTIONS') {
        resultado = { status: 204 };
      } else if (caminho === '/api/saude' && metodo === 'GET') {
        resultado = {
          status: 200,
          corpo: {
            ok: true,
            servico: 'laboratorio-web-diagnostico',
            hora: new Date().toISOString(),
            porta: config.apiPort,
            rotas: ['GET /api/saude', 'GET /api/pedidos', 'POST /api/pedidos', 'GET /api/pedidos/:id'],
          },
        };
      } else if (caminho === '/api/pedidos' && metodo === 'GET') {
        const pedidos = repositorio.listar();
        resultado = { status: 200, corpo: { total: pedidos.length, pedidos } };
      } else if (caminho === '/api/pedidos' && metodo === 'POST') {
        const leitura = await lerCorpoJson(req);
        if (leitura.erro) {
          resultado = { status: 400, corpo: { erro: 'JSON inválido', detalhe: leitura.erro } };
        } else {
          const detalhes = validarPedido(leitura.valor);
          if (detalhes.length > 0) {
            resultado = {
              status: 400,
              corpo: {
                erro: 'Dados inválidos',
                mensagem: 'A API não aceitou o cadastro. Veja "detalhes" para saber quais campos falharam.',
                detalhes,
              },
            };
          } else {
            const corpo = leitura.valor;
            const pedido = repositorio.criar({
              cliente: corpo.cliente.trim(),
              telefone: typeof corpo.telefone === 'string' ? corpo.telefone.trim() : '',
              produto: corpo.produto.trim(),
              quantidade: corpo.quantidade,
              retiradaEm: new Date(corpo.retiradaEm).toISOString(),
            });
            resultado = { status: 201, corpo: pedido, headers: { Location: `/api/pedidos/${pedido.id}` } };
          }
        }
      } else if (/^\/api\/pedidos\/\d+$/.test(caminho) && metodo === 'GET') {
        const id = Number(caminho.split('/').pop());
        const pedido = repositorio.listar().find((item) => item.id === id);
        resultado = pedido
          ? { status: 200, corpo: pedido }
          : { status: 404, corpo: { erro: 'Pedido não encontrado', id } };
      } else if (rotasPermitidas(caminho)) {
        resultado = {
          status: 405,
          corpo: { erro: 'Método não permitido', metodo, caminho, permitidos: rotasPermitidas(caminho) },
        };
      } else {
        resultado = {
          status: 404,
          corpo: {
            erro: 'Rota não encontrada',
            metodo,
            caminho,
            dica: 'Rotas disponíveis: GET /api/saude, GET /api/pedidos, POST /api/pedidos, GET /api/pedidos/:id',
          },
        };
      }
    } catch (erro) {
      resultado = { status: 500, corpo: { erro: 'Erro interno do laboratório', detalhe: String(erro?.message ?? erro) } };
    }

    // Regra de CORS do laboratório: o preflight sempre passa; no cenário 4, a resposta
    // do POST sai sem Access-Control-Allow-Origin (o pedido é criado, mas o navegador
    // não deixa o JavaScript ler a resposta).
    const ehPreflight = metodo === 'OPTIONS';
    const bloqueioDeLeitura = Boolean(desafios.cors) && metodo === 'POST';
    const cors = cabecalhosCors(req, config, ehPreflight || !bloqueioDeLeitura);
    responder(res, resultado, cors);

    const origem = req.headers.origin ? ` origem=${req.headers.origin}` : '';
    console.log(`[api] ${agora()} ${metodo} ${caminho} -> ${resultado.status}${origem}`);
  };
}

export function criarServidorApi(opcoes = {}) {
  const {
    config = lerConfig(),
    lerEstado = lerEstadoDesafios,
    caminhoDados = CAMINHO_DADOS_PADRAO,
  } = opcoes;
  const repositorio = criarRepositorio(caminhoDados);
  const manipular = criarManipulador({ repositorio, config, lerEstado });
  return createServer((req, res) => {
    void manipular(req, res);
  });
}

export function iniciar() {
  const config = lerConfig();
  const caminhoDados = process.env.LAB_DADOS || CAMINHO_DADOS_PADRAO;
  const servidor = criarServidorApi({ config, caminhoDados });
  servidor.on('error', (erro) => {
    if (erro.code === 'EADDRINUSE') {
      console.error(`[api] a porta ${config.apiPort} já está em uso.`);
      console.error('[api] ajuste "apiPort" em lab.config.json ou rode: LAB_API_PORT=3111 npm run api');
    } else {
      console.error('[api] falha ao iniciar:', erro);
    }
    process.exit(1);
  });
  servidor.listen(config.apiPort, config.apiHost, () => {
    const estado = lerEstadoDesafios();
    console.log(`[api] no ar em http://${config.apiHost}:${config.apiPort}`);
    console.log(`[api] dados em: ${caminhoDados}`);
    console.log(`[api] desafios ativos: ${estado.ativos.length ? estado.ativos.map((n) => `#${n}`).join(', ') : 'nenhum'}`);
  });
  return servidor;
}

const ehPrincipal = process.argv[1] && realpathSync(process.argv[1]) === fileURLToPath(import.meta.url);
if (ehPrincipal) iniciar();
