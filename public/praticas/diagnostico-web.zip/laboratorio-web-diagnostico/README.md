# Laboratório Web de diagnóstico

Use Node.js 18.17 ou superior. Na pasta extraída, rode `npm run dev` e abra http://localhost:5180.

Em outro terminal, rode `npm run desafio -- listar`. Use `npm run desafio -- ativar 1` para a rota 404 ou `npm run desafio -- ativar 2` para o formulário 400. Recarregue a página a cada mudança. Ao terminar, rode `npm run desafio -- restaurar`.

Use o roteiro do Percurso Web ou consulte `DESAFIOS.md`. Anote suas evidências antes de abrir `SOLUCOES.md`. Rode `npm run testes` para testar o laboratório.
