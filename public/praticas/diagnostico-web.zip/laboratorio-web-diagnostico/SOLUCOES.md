# Soluções dos desafios

> ⚠️ Só leia depois de tentar. Cada seção traz: causa raiz, onde está no código, como confirmar, como um time corrigiria de verdade e como restaurar.

Como todos os cenários são ligados/desligados por `desafios/estado.json`, a restauração é sempre a mesma antes de mexer no código:

```bash
npm run desafio -- desativar <n>   # ou: npm run desafio -- restaurar
```

E depois F5 na página. Recarregue o servidor apenas se ele estiver no ar com código alterado por você.

---

## Desafio 1 — Rota errada (404)

**Causa raiz.** A página monta a URL da listagem como `/api/pedido` (singular), mas a API expõe `/api/pedidos`. Como a rota não existe, o servidor responde 404 com um JSON explicando ("Rota não encontrada") — a interface não esconde a falha, ela só não a corrige.

**Onde está.** `public/nucleo.js`, função `urls()`:

```js
lista: `${base}${desafios.rotaErrada ? '/api/pedido' : '/api/pedidos'}`,
```

**Como confirmar.** Na aba Rede, a requisição aparece como `GET http://localhost:3101/api/pedido` → 404. O contraste é o `GET /api/saude` → 200, que continua correto.

**Correção de verdade (num projeto real).** A URL não deve divergir do contrato da API. Opções comuns:

- Corrigir a rota na página para `/api/pedidos` (o que `desativar 1` faz).
- Centralizar as rotas em um único lugar (aqui, `nucleo.js` já cumpre esse papel) para que frontend e API não fiquem com "singular/plural" desalinhados.
- Antes de tudo, a API deve continuar respondendo 404 explícito — foi o que permitiu diagnosticar rápido.

**Detalhe didático.** O status 404 aparece na requisição certa, não na página: repare que o selo "API ok" fica verde o tempo todo. O problema é a URL, não a disponibilidade.

---

## Desafio 2 — Cadastro rejeitado (400)

**Causa raiz.** O corpo enviado no POST não segue o contrato da API: o nome da cliente vai no campo `nome` (a API espera `cliente`) e a data de retirada nem é enviada (a API exige `retiradaEm`). A API recusa com 400 e detalha exatamente quais campos falharam — o que torna o problema localizável a partir do painel Rede.

**Onde está.** `public/nucleo.js`, função `montarPayload()`:

```js
if (desafios.cadastroRejeitado) {
  const comContratoAlterado = { ...payload, nome: payload.cliente };
  delete comContratoAlterado.cliente;
  delete comContratoAlterado.retiradaEm;
  return comContratoAlterado;
}
```

E a validação que produz o 400 fica em `servidor/api.mjs`, função `validarPedido()`.

**Como confirmar.** Aba Rede → `POST /api/pedidos` → **Carga de solicitação** mostra `nome` e nenhum `retiradaEm`; a **Resposta** mostra:

```json
{
  "erro": "Dados inválidos",
  "detalhes": [
    { "campo": "cliente", "mensagem": "informe o nome do cliente (2 a 80 caracteres)" },
    { "campo": "retiradaEm", "mensagem": "informe a data de retirada em formato ISO (…)" }
  ]
}
```

**Correção de verdade (num projeto real).**

- O frontend deve montar o payload com os mesmos nomes de campo que a API valida (o correto é o que `desativar 2` restaura).
- Vale manter a validação nos dois lados: no cliente para dar retorno rápido, na API como fonte da verdade — afinal é ela que responde 400 com o detalhamento.
- Em equipe, um contrato explícito (tabela de campos no README ou tipos compartilhados) evita exatamente esse tipo de "rename" silencioso.

**Detalhe didático.** 400 é uma resposta de **dados** (o servidor está no ar e processou a requisição). Isso o distingue de falhas de rede (desafio 3) e de CORS (desafio 4), em que a requisição pode nem chegar — ou chegar e a resposta não poder ser lida.

---

## Desafio 3 — API inacessível (conexão recusada)

**Causa raiz.** O frontend monta a base da API com `apiPortaErrada` (4099) em vez de `apiPort` (3101). Não há nada escutando na 4099, então o sistema operacional recusa a conexão e o `fetch` rejeita com `TypeError: Failed to fetch`. Na aba Rede isso vira `(failed)` / `net::ERR_CONNECTION_REFUSED` — diferente de um status HTTP: **não houve resposta**.

**Onde está.** `public/nucleo.js`, função `baseApi()`:

```js
export function baseApi(config, desafios = DESAFIOS_PADRAO) {
  if (desafios.apiInacessivel) {
    return `http://${config.apiHost}:${config.apiPortaErrada}`;
  }
  return `http://${config.apiHost}:${config.apiPort}`;
}
```

**Como confirmar.** Compare a URL que falhou na Rede (porta 4099) com o endereço impresso pelo terminal da API (porta 3101) e com `GET http://localhost:3101/api/saude` funcionando no navegador.

**Correção de verdade (num projeto real).**

- Centralizar a base da API em **uma** configuração de ambiente (variável de build/deploy) e garantir que o endereço apontado exista — o `config.js` servido pelo servidor web já faz esse papel aqui.
- Tratar falha de conexão na interface com uma mensagem acionável (o que a página faz: orienta abrir Console/Rede).
- Em produção, isso costuma aparecer quando o frontend é publicado apontando para um host/porta de API que não existe naquele ambiente (ex.: `localhost` no lugar do domínio da API).

**Detalhe didático.** `(failed)` na coluna Status é a pista central: não é 500, não é 404 — é ausência de resposta. CORS (desafio 4) também pode gerar `TypeError` no `fetch`, mas na Rede o POST **aparece com status** (ex.: 201) e o Console mostra "blocked by CORS policy". Saber diferenciar os dois é o objetivo.

---

## Desafio 4 — CORS bloqueando a leitura da resposta

**Causa raiz.** O frontend roda em `http://localhost:5180` e a API em `http://localhost:3101` — origens diferentes (porta diferente já é outra origem). Por isso o navegador aplica a política de mesma origem e exige que a API autorize a leitura com o cabeçalho `Access-Control-Allow-Origin`. Com o cenário ativo, a API responde ao POST **sem** esse cabeçalho. O preflight (`OPTIONS`) continua liberado, então o POST chega ao servidor e o pedido é gravado (201). O que falha é a última etapa: o navegador bloqueia a entrega da resposta ao `fetch`, que rejeita com `TypeError: Failed to fetch`.

**Onde está.** `servidor/api.mjs`:

```js
const ehPreflight = metodo === 'OPTIONS';
const bloqueioDeLeitura = Boolean(desafios.cors) && metodo === 'POST';
const cors = cabecalhosCors(req, config, ehPreflight || !bloqueioDeLeitura);
```

E `cabecalhosCors()` monta `Access-Control-Allow-Origin` apenas quando `permitir` é verdadeiro.

**Como confirmar.** Na aba Rede: GET com `Access-Control-Allow-Origin: http://localhost:5180`; POST 201 **sem** esse cabeçalho. No Console: "has been blocked by CORS policy: No 'Access-Control-Allow-Origin' header is present on the requested resource".

**Correção de verdade (num projeto real).**

- A API deve responder com `Access-Control-Allow-Origin` contendo a origem do frontend (como o laboratório faz fora do cenário), e responder corretamente ao preflight com `Access-Control-Allow-Methods` e `Access-Control-Allow-Headers`.
- Liberar origens específicas (nunca refletir qualquer origem sem critério; `*` não funciona com cookies/credenciais).
- Alternativa comum em produção: publicar frontend e API sob a **mesma origem** (mesmo domínio), usando proxy reverso (`/api` → servidor da API). Aí não há CORS.
- CORS é uma proteção **do navegador**, não da API: `curl` sempre lê a resposta. Por isso segurança de verdade não pode depender de CORS.

**Detalhe didático.** Note a diferença para o desafio 3: lá a requisição não chega a lugar nenhum (`(failed)`); aqui ela chega, o servidor responde 201 e cria o pedido — o bloqueio é só na leitura. É o famoso "funcionou no Postman, mas não no navegador".

---

## Desafio 5 — Lista desatualizada (201, mas o item não aparece)

**Causa raiz.** O fluxo de cadastro trata corretamente a resposta 201 (mostra a mensagem de sucesso), mas **não atualiza a lista** em seguida. Os dados no servidor estão certos — é o estado da tela que ficou velho (stale). Ao recarregar a página, a listagem busca os dados de novo e o pedido aparece. Não há erro de rede nem de HTTP: o painel Rede mostra 201, e o Console fica limpo.

**Onde está.** `public/app.js`, bloco de sucesso do `enviarCadastro()`:

```js
if (deveRecarregarLista(DESAFIOS)) {
  await carregarPedidos();
}
```

E a decisão, em `public/nucleo.js`:

```js
export function deveRecarregarLista(desafios = DESAFIOS_PADRAO) {
  return !desafios.listaDesatualizada;
}
```

**Como confirmar.** O POST responde 201 e a resposta contém o pedido com `id` novo. A tabela não muda. Ao dar F5, o `GET /api/pedidos` seguinte traz o pedido. Ou seja: API e persistência funcionam; falta a atualização da UI.

**Correção de verdade (num projeto real).**

- Após um cadastro bem-sucedido, atualizar o estado local — recarregar a lista do servidor (mais simples e consistente) ou inserir o pedido retornado pela API na lista já carregada (otimista).
- Em frameworks reativos (React, Vue etc.), o problema equivalente é não atualizar o estado/cache após a mutação; ferramentas de data fetching têm invalidação de cache justamente para isso.
- Evitar "confiar na sorte": um teste automatizado do fluxo "cadastrar → item aparece na lista" pega essa regressão. Aqui, `deveRecarregarLista` é testável e a suíte cobre a decisão.

**Detalhe didático.** Compare com o desafio 4: lá a resposta não podia ser lida; aqui ela é lida com sucesso (a mensagem verde prova) e mesmo assim a tela fica desatualizada. É o exemplo típico de bug de **estado de interface**, não de rede/API — e o painel Rede ajuda a excluir as hipóteses de servidor antes de olhar o código do fluxo.
