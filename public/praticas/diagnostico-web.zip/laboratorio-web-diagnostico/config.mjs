// Configuração central do laboratório: portas, estado dos desafios e utilidades.
// As portas podem ser mudadas em lab.config.json ou pelas variáveis de ambiente
// LAB_API_HOST, LAB_API_PORT, LAB_WEB_HOST, LAB_WEB_PORT, LAB_API_PORTA_ERRADA.
import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

export const RAIZ = dirname(fileURLToPath(import.meta.url));

const PADROES = {
  apiHost: 'localhost',
  apiPort: 3101,
  webHost: 'localhost',
  webPort: 5180,
  apiPortaErrada: 4099,
};

const CAMINHO_CONFIG = join(RAIZ, 'lab.config.json');
const CAMINHO_ESTADO = join(RAIZ, 'desafios', 'estado.json');

function lerArquivoConfig() {
  if (!existsSync(CAMINHO_CONFIG)) return { ...PADROES };
  try {
    return { ...PADROES, ...JSON.parse(readFileSync(CAMINHO_CONFIG, 'utf8')) };
  } catch (erro) {
    console.error(`[config] lab.config.json inválido, usando padrões. Detalhe: ${erro.message}`);
    return { ...PADROES };
  }
}

export function lerConfig(env = process.env) {
  const base = lerArquivoConfig();
  return {
    apiHost: env.LAB_API_HOST || base.apiHost,
    apiPort: Number(env.LAB_API_PORT || base.apiPort),
    webHost: env.LAB_WEB_HOST || base.webHost,
    webPort: Number(env.LAB_WEB_PORT || base.webPort),
    apiPortaErrada: Number(env.LAB_API_PORTA_ERRADA || base.apiPortaErrada),
  };
}

// Cadastro dos desafios do laboratório. Cada desafio tem um número fixo;
// o estado (ligado/desligado) fica em desafios/estado.json.
export const DESAFIOS = [
  { numero: 1, chave: 'rotaErrada', titulo: 'Rota errada (404)' },
  { numero: 2, chave: 'cadastroRejeitado', titulo: 'Cadastro rejeitado (400)' },
  { numero: 3, chave: 'apiInacessivel', titulo: 'API inacessível (conexão recusada)' },
  { numero: 4, chave: 'cors', titulo: 'CORS bloqueando a leitura da resposta' },
  { numero: 5, chave: 'listaDesatualizada', titulo: 'Lista desatualizada após o cadastro (201)' },
];

export function lerEstadoDesafios() {
  try {
    const conteudo = JSON.parse(readFileSync(CAMINHO_ESTADO, 'utf8'));
    const ativos = Array.isArray(conteudo.ativos) ? conteudo.ativos.map(Number).filter(Number.isInteger) : [];
    return { atualizadoEm: conteudo.atualizadoEm ?? null, ativos };
  } catch {
    return { atualizadoEm: null, ativos: [] };
  }
}

export function salvarEstadoDesafios(ativos) {
  mkdirSync(dirname(CAMINHO_ESTADO), { recursive: true });
  const conteudo = {
    atualizadoEm: new Date().toISOString(),
    ativos: [...new Set(ativos.map(Number))].filter(Number.isInteger).sort((a, b) => a - b),
  };
  writeFileSync(CAMINHO_ESTADO, `${JSON.stringify(conteudo, null, 2)}\n`);
  return conteudo;
}

// Converte a lista de números ativos no mapa de chaves usado pelo frontend e pela API.
export function mapaDesafios(ativos = []) {
  const conjunto = new Set(ativos.map(Number));
  return Object.fromEntries(DESAFIOS.map((desafio) => [desafio.chave, conjunto.has(desafio.numero)]));
}
